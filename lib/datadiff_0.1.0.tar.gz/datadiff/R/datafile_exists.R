#' Determine whether a data file exists
#'
#' @param source
#' The data source (as a character string).
#' @param dataset
#' The name of the dataset.
#' @param ...
#' Additional arguments passed to the \code{\link{fetch_data}} function.
#'
#' @return A logical.
#'
#' @seealso \code{\link{datasets}}
#'
#' @examples
#' \dontrun{
#' datafile_exists(source = "uci", dataset = "iris")
#' datafile_exists(source = "data.gov.uk", dataset = "broadband", year = 2014)
#' }
#'
#' @export
datafile_exists <- function(source, dataset, ...) {

  path <- storage_path(source = source, dataset = dataset,
                       storage_root = storage_root_dir())

  if (identical(tolower(source), "uci"))
    return(file.exists(path))

  if (identical(tolower(source), "data.gov.uk")) {
    dots <- list(...)
    stopifnot("year" %in% names(dots))

    year <- as.character(dots[["year"]])
    files <- list.files(path)

    # The broadband dataset for November 2015 does not contain the string "2015"
    # so we match on the specific filename for this case.
    if (identical(tolower(dataset), "broadband") &&
        identical(as.character(year), "2015"))
      return(any(files == "panellist-data.csv.xls"))

    return(any(stringr::str_detect(files, pattern = year)))
  }

  stop(paste("Data source not found:", source))
}
