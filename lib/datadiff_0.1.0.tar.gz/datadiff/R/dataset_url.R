#' Get a vector of valid dataset names for a given source
#'
#' @param source
#' The data source (as a character string).
#' @param dataset
#' The name of the dataset.
#' @param ...
#' Additional arguments.
#'
#' @return A character vector of dataset names.
#'
#' @export
dataset_url <- function(source, dataset, ...) {

  stopifnot(dataset %in% datasets(source))

  if (identical(tolower(source), "uci")) {
    stub <- "http://archive.ics.uci.edu/ml/machine-learning-databases"
    return(paste0(file.path(stub, dataset), "/"))
  }

  if (identical(tolower(source), "data.gov.uk")) {
    dots <- list(...)
    stopifnot("year" %in% names(dots))
    if (identical(tolower(dataset), "broadband")) {
      stub <- "https://www.ofcom.org.uk/__data/assets"
      return(file.path(stub, broadband_url(dots[["year"]])))
    }
    stop(paste("Dataset", dataset, "not found for source:", source))
  }

  stop(paste("Data source not found:", source))
}

broadband_url <- function(year) {

  stopifnot(length(year) == 1)
  switch(as.character(year),
         "2013" = "excel_doc/0028/54775/november_2013.csv.xls",
         "2014" = "excel_doc/0014/74120/panellist_data_november_2014.csv.xls",
         "2015" = "excel_doc/0015/50073/panellist-data.csv.xls",
         "2016" = "file/0019/100756/UK-home-broadband-performance,-November-2016-Panellist-data.csv",
         stop(paste("Invalid year argument for broadband dataset:", year)))
}
