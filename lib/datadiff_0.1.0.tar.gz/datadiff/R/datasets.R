#' Get a vector of valid dataset names for a given source
#'
#' @param source
#' The data source (as a character string).
#'
#' @return A character vector of dataset names.
#'
#' @export
datasets <- function(source) {

  if (identical(tolower(source), "uci"))
    return(c(
      "iris",
      "adult",
      "wine",
      "car",
      "forest-fires",
      "breast-cancer-wisconsin",
      "00240",
      "abalone",
      "wine-quality",
      "heart-disease"
    ))

  if (identical(tolower(source), "data.gov.uk"))
    return(c(
      "broadband"
    ))

  stop(paste("Data source not found:", source))
}
