#' Fetch a dataset from a remote source
#'
#' Vectorised over the dataset argument.
#'
#' @param dataset
#' The name of the dataset.
#' @param source
#' The data source (as a character string).
#' @param path
#' The directory path to which the data will be saved. Defaults to the designated
#' storage location for the given \code{source} and \code{dataset}, under the
#' package installation directory.
#' @param ...
#' Additional arguments passed to the \code{\link{dataset_url}} function.
#'
#' @return No return value.
#'
#' @seealso \code{\link{storage_path}}
#'
#' @export
fetch_data <- function(dataset, source = "uci",
                       path = storage_path(source, dataset = dataset,
                                           storage_root = storage_root_dir()),
                       ...) {

  stopifnot(all(dataset %in% datasets(source)))

  sink <- sapply(dataset, FUN = function(d) {

    options = c("recursive",
                "no-parent",
                "no-directories",
                "no-host-directories",
                paste("directory-prefix", path))

    str_options <- paste0("--", options, collapse = " ")
    str_url <- dataset_url(source, d, ...)

    command <- paste("wget", str_options, str_url)
    err_code <- system(command, intern = FALSE)

    if (err_code != 0)
      warning(paste("Attempt to fetch dataset", d, "returned error code:", err_code))
  })
}
