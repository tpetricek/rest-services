#' Calibrate penalty parameters by iterative bootstrapping
#'
#' @param df
#' A data frame.
#' @param datadiff
#' The datadiff function for the experiment.
#' @param patch_generators
#' A list of patch generator functions from which candidate patches will be generated.
#' @param patch_penalties
#' A numeric vector of patch penalties corresponding to the \code{patch_generators}
#' list. The lengths of these two arguments must be equal.
#' @param permute_penalty
#' The penalty associated with a permutation patch.
#' @param break_penalty
#' The penalty associated with a break patch.
#' @param N
#' The number of experiments (i.e. random splits of the data). Defaults to 20.
#' @param split
#' A number in the unit interval specifying the splitting ratio.
#' @param seed
#' A random seed. By default an integer seed is chosen at random.
#' @param target_fpr
#' The target false positive rate.
#' @param acceptance_margin
#' The acceptable margin around the target false positive rate.
#' @param increment_factor
#' The factor by which penalties are incremented between iterations.
#' @param decrement_factor
#' The factor by which penalties are decremented between iterations.
#' @param boundary
#' The boundary at the ends of the unit interval which determines the domain
#' for patch penalty values.
#' @param logfile
#' The full path to a logfile. Defaults to \code{log/datadiff.log} under the
#' package installation directory.
#'
#' @return A named numeric vector.
#'
#' @export
iterative_calibration <- function(df,
                                  datadiff = ddiff,
                                  patch_generators = list(gen_patch_rescale, gen_patch_recode),
                                  patch_penalties = c(0.8, 0.8),
                                  permute_penalty = 0.1,
                                  break_penalty = 0.95,
                                  N = 4, # TODO: N = 500
                                  split = 0.5,
                                  seed = sample.int(.Machine$integer.max, size = 1),
                                  target_fpr = 0.05,
                                  acceptance_margin = 0.1,
                                  increment_factor = 1.2,
                                  decrement_factor = 0.8,
                                  boundary = 10^(-6),
                                  # TODO: pb = TRUE,
                                  logfile = system.file("log/datadiff.log", package = "datadiff")) {


  ##### TODO: Extend to work jointly on multiple datasets (i.e. by
  # "combining the histograms").


  # Procedure:
  #
  # 1.  Pick a set of sample datasets (e.g. top 10 from UCI ML archive)
  # here we do for one dataset
  # 2. For each sample dataset:
  # 3.  Bootstrap the dataset (i.e. randomly partition rows into two subsamples N times without replacement).
  # 4. Pick some penalty parameters arbitrarily
  # 5. Run datadiff on each subsample (we know the result should be the identity)
  # 6. Compute the false positive rate for each patch type.
  # if that percentage is close to our target \alpha, keep the penalty parameter for that type.
  # if the observed false positive rate is too high, multiply the penalty by 1.2 (say)
  # if it's too low, multiply by 0.8 (say)
  # 7. Goto step 5 & repeat until all parameters converge.


  stopifnot(length(split) == 1)
  stopifnot(target_fpr > 0 && target_fpr < 1)
  stopifnot(acceptance_margin > 0 && acceptance_margin < 1)
  stopifnot(increment_factor > 1)
  stopifnot(decrement_factor < 1)
  stopifnot(decrement_factor > 0)

  # Check that N, target_fpr and acceptance_margin are jointly sensible.
  if (1/N > 2 * acceptance_margin * target_fpr)
    stop("Incompatible parameters. Try increasing N.")

  logging::addHandler(logging::writeToFile, file=logfile, level='DEBUG')
  logging::loginfo("Iterative calibration with N = %d, target = %f, margin = %f, seed = %d",
                   N, target_fpr, acceptance_margin, seed)

  gen_types <- generator_type(df, patch_generator = patch_generators,
                               short = TRUE)
  # MOVED TO SEPARATE FUNCTION:
  # # Construct a nested list containing all patch types, by applying the given
  # # patch_generators to each column of the data.
  # dfs <- split_data(df, split = split)
  # patches <- purrr::map(patch_generators, .f = function(gen) {
  #   purrr::discard(
  #     purrr::map(1:ncol(df), .f = function(col) {
  #       tryCatch(
  #         gen(df1 = dfs[[1]], df2 = dfs[[2]], col1 = col),
  #         error = function(e) { NULL })
  #     }),
  #     .p = is.null)
  # })
  #
  # # Identify all relevant patch types (in order corresponding to the
  # # patch_generators vector). The patch type in each sublist of 'patches' is
  # # unique (because the same elementary patch generator was used). Assign NA
  # # for any patch type that is incompatible with _all_ columns.
  # gen_types <- purrr::map_chr(patches, .f = function(sublist) {
  #   type <- unique(purrr::map_chr(sublist, .f = patch_type, short = TRUE))
  #   if (length(type) == 0)
  #     return(NA)
  #   type
  # })

  # Drop any incompatible patch types.
  is_compatible_type <- !is.na(gen_types)
  patch_generators <- patch_generators[is_compatible_type]
  gen_types <- gen_types[is_compatible_type]

  candidate_patch_penalties <- patch_penalties[is_compatible_type]
  names(candidate_patch_penalties) <- gen_types[is_compatible_type]

  # Add the permute patch type to get the complete set of relevant types.
  permute_type <- patch_type(patch_permute(1L), short = TRUE)
  types <- c(gen_types[is_compatible_type], permute_type)

  candidate_permute_penalty <- permute_penalty
  names(candidate_permute_penalty) <- patch_type(patch_permute(1L), short = TRUE)

  candidate_penalties <- c(candidate_patch_penalties, candidate_permute_penalty)

  # TODO NEXT:
  # Before starting the loop, do a single experiment with all parameters set
  # to the boundary value (i.e. the minimum value to which the loop might
  # converge). Then do a sanity check by looking at these maximum possible
  # false positive rates. If any are below (1 - acceptance_margin) * target_fpr
  # then there's no chance of successfully calibrating those parameters.
  run_experiment <- function(candidate_penalties) {
    experiment_datadiff <- purrr::partial(datadiff,
                                          patch_generators = patch_generators,
                                          patch_penalties = candidate_penalties[gen_types],
                                          permute_penalty = candidate_penalties[permute_type],
                                          break_penalty = break_penalty)
    config <- configure_synthetic_experiment(df,
                                             datadiff = experiment_datadiff,
                                             N = N,
                                             split = split,
                                             seed = seed)
    execute_synthetic_experiment(config, logfile = logfile)
  }

  boundary_penalties <- rep(boundary, times = length(candidate_penalties))
  names(boundary_penalties) <- names(candidate_penalties)
  boundary_result <- run_experiment(boundary_penalties)

  ### TODO FROM HERE (next step is to do the sanity check described above).

  is_acceptable_fpr <- function(x) {
    x > (1 - acceptance_margin) * target_fpr &
      x < (1 + acceptance_margin) * target_fpr
  }

  while(TRUE) {
    logging::loginfo(paste("Current candidates:",
                           paste(c(rbind(names(candidate_penalties), candidate_penalties)),
                                 collapse = " ")))

    # Run a synthetic experiment with the candidate penalty parameters.
    result <- run_experiment(candidate_penalties)
    #old:
    # experiment_datadiff <- purrr::partial(datadiff,
    #                            patch_generators = patch_generators,
    #                            patch_penalties = candidate_penalties[gen_types],
    #                            permute_penalty = candidate_penalties[permute_type],
    #                            break_penalty = break_penalty)
    # config <- configure_synthetic_experiment(df,
    #                                          datadiff = experiment_datadiff,
    #                                          N = N,
    #                                          split = split,
    #                                          seed = seed)
    # result <- execute_synthetic_experiment(config, logfile = logfile)

    # Compute the false positive rates for all patch types.
    fpr <- false_positive_rate(result, type = types)
    accept <- is_acceptable_fpr(fpr)

    logging::loginfo(paste("False positive rate:", paste(c(rbind(names(fpr), fpr)),
                                                collapse = " ")))
    logging::loginfo(paste("Acceptance:", paste(c(rbind(names(accept), accept)),
                                 collapse = " ")))

    # If all false positive rates are within the acceptance margin, return the
    # current parameters.
    if (all(accept))
      return(candidate_penalties)

    # Guarantee an eventual exit.
    if (any(candidate_penalties <= boundary | candidate_patch_penalties >= (1 - boundary))) {
      logging::loginfo("Iterative calibration attempt failed: hit boundary at %f",
                       boundary)
      return(NA)
    }

    # If any false positive rates exceed the target + margin, increment the
    # corresponding candidate penalties.
    to_increment <- !accept & fpr > target_fpr
    if (any(to_increment))
      candidate_penalties[to_increment] <- min(increment_factor * candidate_penalties[to_increment], 1 - boundary)

    # If any false positive rates fall below the target - margin, decrement the
    # corresponding candidate penalties.
    to_decrement <- !accept & fpr < target_fpr
    if (any(to_decrement))
      candidate_penalties[to_decrement] <- max(decrement_factor * candidate_penalties[to_decrement], boundary)
  }
}
