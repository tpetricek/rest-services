#' Read a dataset
#'
#' Vectorised over the dataset argument.
#'
#' @param dataset
#' The name of the dataset. Use the \code{\link{datasets}} function to get a
#' list of all datasets for a given source.
#' @param source
#' The data source (as a character string).
#' @param storage_root
#' The path to the root directory for data storage. By default this argument
#' takes the value returned by the \code{\link{storage_root_dir}} function.
#' @param ...
#' Additional arguments passed to the \code{\link{fetch_data}} function.
#'
#' @return A data frame, or a named list of data frames if \code{dataset} has
#' multiple elements.
#'
#' @seealso \code{\link{datasets}}
#'
#' @examples
#' \dontrun{
#' df <- read_data(dataset = "iris", source = "uci")
#' }
#'
#' @export
read_data <- function(dataset, source = "uci",
                      storage_root = storage_root_dir(), ...) {

  stopifnot(all(dataset %in% datasets(source)))

  ret <- purrr::map(dataset, .f = function(d) {

    path <- storage_path(source, dataset = d, storage_root = storage_root)
    if (!datafile_exists(source = source, dataset = d, ...))
      fetch_data(dataset = d, source = source, path = path, ...)

    do.call(paste("read", stringr::str_replace_all(d, "-", "_") , sep = "_"),
            args = list(path, ...))
  })

  if (length(ret) == 1)
    return(ret[[1]])

  names(ret) <- dataset
  ret
}

# Read the UCI 00240 dataset
read_00240 <- function(path) {

  subdirectory <- "UCI HAR Dataset"
  if (!file.exists(file.path(path, subdirectory))) {
    zipfile <- file.path(path, "UCI HAR Dataset.zip")
    if (file.exists(zipfile))
      utils::unzip(zipfile, exdir = path)
    else
      stop("Neither subdirectory nor zipfile exist.")
  }

  col.names <- utils::read.table(file.path(path, subdirectory, "features.txt"),
                                 header = FALSE, stringsAsFactors = FALSE)[[2]]

  train_directory <- file.path(path, subdirectory, "train")
  ret <- utils::read.table(file.path(train_directory, "X_train.txt"),
                           header = FALSE, col.names = col.names, stringsAsFactors = FALSE)

  ret[["subject"]] <- readLines(file.path(train_directory, "subject_train.txt"))

  ret[["label"]] <- readLines(file.path(train_directory, "y_train.txt"))
  ret
}

# Read the UCI abalone dataset
read_abalone <- function(path) {

  col.names <- c("Sex",
                 "Length",
                 "Diameter",
                 "Height",
                 "Whole weight",
                 "Shucked weight",
                 "Viscera weight",
                 "Shell weigth",
                 "Rings")

  utils::read.csv(file.path(path, "abalone.data"), header = FALSE,
                  col.names = col.names, stringsAsFactors = FALSE)
}

# Read the UCI adult dataset
read_adult <- function(path) {

  col.names <- c("age",
                 "workclass",
                 "fnlwgt",
                 "education",
                 "education-num",
                 "marital-status",
                 "occupation",
                 "relationship",
                 "race",
                 "sex",
                 "capital-gain",
                 "capital-loss",
                 "hours-per-week",
                 "native-country",
                 "label")

  utils::read.csv(file.path(path, "adult.data"), header = FALSE,
                  col.names = col.names, stringsAsFactors = FALSE)
}

# Read the UCI breast cancer wisconsin dataset
read_breast_cancer_wisconsin <- function(path) {

  col.names <- c("Sample code number",
                 "Clump Thickness",
                 "Uniformity of Cell Size",
                 "Uniformity of Cell Shape",
                 "Marginal Adhesion",
                 "Single Epithelial Cell Size",
                 "Bare Nuclei",
                 "Bland Chromatin",
                 "Normal Nucleoli",
                 "Mitoses",
                 "Class")

  utils::read.csv(file.path(path, "breast-cancer-wisconsin.data"), header = FALSE,
                  col.names = col.names, stringsAsFactors = FALSE)
}

# Read the UCI car dataset
read_car <- function(path) {

  col.names <- c("buying",
                 "maint",
                 "doors",
                 "persons",
                 "lug_boot",
                 "safety",
                 "CAR")

  utils::read.csv(file.path(path, "car.data"), header = FALSE,
                  col.names = col.names, stringsAsFactors = FALSE)
}

# Read the UCI forest-fires dataset
read_forest_fires <- function(path) {

  utils::read.csv(file.path(path, "forestfires.csv"), header = TRUE,
                  stringsAsFactors = FALSE)
}

# Read the UCI heart-disease dataset
# NB: Cleveland "processed" dataset only.
read_heart_disease <- function(path) {

  col.names <- c("age",
                 "sex",
                 "cp",
                 "trestbps",
                 "chol",
                 "fbs",
                 "restecg",
                 "thalach",
                 "exang",
                 "oldpeak",
                 "slope",
                 "ca",
                 "thal",
                 "num")

  utils::read.csv(file.path(path, "processed.cleveland.data"), header = FALSE,
                  col.names = col.names, stringsAsFactors = FALSE)
}

# Read the UCI iris dataset
read_iris <- function(path) {

  col.names <- c("sepal_length",
                 "sepal_width",
                 "petal_length",
                 "petal_width",
                 "class")

  utils::read.csv(file.path(path, "iris.data"), header = FALSE,
                  col.names = col.names, stringsAsFactors = FALSE)
}

# Read the UCI wine-quality dataset
# NB: White wine dataset only (the variety is Vinho Verde).
read_wine_quality <- function(path) {

  utils::read.csv(file.path(path, "winequality-white.csv"), header = TRUE, sep = ";",
                  check.names = FALSE, stringsAsFactors = FALSE)
}

# Read the UCI wine dataset
read_wine <- function(path) {

  col.names <- c("type",
                 "Alcohol",
                 "Malic acid",
                 "Ash",
                 "Alcalinity of ash",
                 "Magnesium",
                 "Total phenols",
                 "Flavanoids",
                 "Nonflavanoid phenols",
                 "Proanthocyanins",
                 "Color intensity",
                 "Hue",
                 "OD280/OD315 of diluted wines",
                 "Proline")

  utils::read.csv(file.path(path, "wine.data"), header = FALSE,
                  col.names = col.names, stringsAsFactors = FALSE)
}

# Read the data.gov.uk broadband dataset
read_broadband <- function(path, ...) {

  dots <- list(...)
  stopifnot("year" %in% names(dots))

  year <- as.character(dots[["year"]])
  files <- list.files(path)

  if (identical(year, "2015"))
    match <- files == "panellist-data.csv.xls"
  else
    match <- stringr::str_detect(files, pattern = year)

  stopifnot(any(match)) # No match
  stopifnot(sum(match) == 1) # Ambiguous match

  utils::read.csv(file.path(path, files[match]), header = TRUE,
                  stringsAsFactors = FALSE)
}
