#' Choose column indices at random
#'
#' @param df
#' A data frame.
#' @param condition
#' A predicate to determine valid candidate columns.
#' @param size
#' The number of samples (i.e. column indices) to pick.
#'
#' @return An integer vector of column indices
#'
#' @export
sample_cols <- function(df, condition = is.numeric, size = 1) {

  stopifnot(is.data.frame(df))
  is_candidate_col <- purrr::map_lgl(df, condition)

  if (!any(is_candidate_col))
    stop("No columns satisfy the given condition.")

  candidate_cols <- which(is_candidate_col)

  # Use the sample function with care (i.e. avoid a scalar first argument).
  if (length(candidate_cols) == 1)
    return(candidate_cols)
  sample(candidate_cols, size = size, replace = FALSE)
}
