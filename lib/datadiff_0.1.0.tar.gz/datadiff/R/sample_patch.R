#' Randomly sample a composed patch
#'
#' @param df
#' A data frame
#' @param ...
#' n patch sampler functions to apply in order from right to left.
#'
#' @export
#'
#' @examples
#' p <- sample_patch(mtcars, sample_patch_delete, sample_patch_permute)
#' p
#' head(p(mtcars))
#'
sample_patch <- function(df, ...) {

  # Keep track of the effect on the data of patch samplers already
  # applied (e.g. deleted/inserted columns must be recognised by subsequent
  # elements in a composition of patches).
  running_patch <- patch_identity()
  patch_list <- purrr::map(list(...), .f = function(patch_sampler) {
    p <- patch_sampler(running_patch(df))
    running_patch <<- compose_patch(p, running_patch)
    p
  })
  Reduce(compose_patch, rev(patch_list))
}
