#' Get a path on the filesystem for data storage
#'
#' Vectorised over the \code{dataset} argument.
#'
#' @param source
#' The data source (as a character string).
#' @param dataset
#' (Optional) The name of the dataset.
#' @param storage_root
#' The path to the root directory for data storage.
#'
#' @return A file path.
#'
#' @export
storage_path <- function(source, dataset, storage_root = storage_root_dir()) {

  ret <- file.path(storage_root, source)

  # For backwards compatibility, UCI datasets are stored in a subdirectory.
  if (tolower(source) == "uci")
    ret <- file.path(ret, "ml", "machine-learning-databases")

  if (missing(dataset) || nchar(dataset) == 0)
    return(ret)

  stopifnot(dataset %in% datasets(source))
  file.path(ret, dataset)
}
