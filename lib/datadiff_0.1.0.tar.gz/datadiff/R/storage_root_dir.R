#' Get the path to the root directory for data storage
#'
#' Returns the default location for storage of data fetched from an external
#' source.
#'
#' @param base_directory
#' The name of the base directory against to which relative position of the
#' storage root directory is given by the \code{subdirectory} argument.
#' @param subdirectory
#' The name of the storage root subdirectory, relative to the
#' \code{base_directory}.
#'
#' @return A file path.
#'
#' @export
storage_root_dir <- function(base_directory = "aida-datadiff",
                             subdirectory = file.path("data", "raw")) {

  wd <- getwd()
  if (!stringr::str_detect(wd, pattern = base_directory))
    stop(paste("Failed to detect the", base_directory, "directory"))

  split <- stringr::str_split(wd, pattern = paste0("/", base_directory))
  ret <- file.path(split[[1]][1], base_directory, subdirectory)

  if (!file.exists(ret))
    stop(paste("Default storage root directory", ret, "does not exist."))

  ret
}
