require(testthat)
context("iterative_calibration")

test_that("the iterative_calibration function works", {

  ####
  #### Test with a dummy dataset.
  ####
  generate_normal_df <- function(n) {
    v1 <- rnorm(n)
    v2 <- rnorm(n, sd = 5/4)
    v3 <- rnorm(n, mean = 1/50)
    v4 <- rnorm(n, sd = 2, mean = 4)
    v5 <- rnorm(n, sd = 4, mean = 8)
    data.frame("v1" = v1, "v2" = v2, "v3" = v3, "v4" = v4, "v5" = v5)
  }

  seed <- 147
  set.seed(seed) # Set the seed before generating the data!
  df <- generate_normal_df(500)

  datadiff <- ddiff
  patch_generators <- list(gen_patch_rescale, gen_patch_recode)
  patch_penalties <- c(0.3, 0.2)
  permute_penalty <- 0.02
  break_penalty <- 0.95
  N <- 100
  split <- 0.5
  seed <- .Machine$integer.max
  target_fpr <- 0.1
  # Test with a wide acceptance margin.
  acceptance_margin <- 0.5
  increment_factor <- 1.2
  decrement_factor <- 0.8
  boundary <- 10^(-2)

  result <- iterative_calibration(df = df,
                                  datadiff = datadiff,
                                  patch_generators = patch_generators,
                                  patch_penalties = patch_penalties,
                                  permute_penalty = permute_penalty,
                                  break_penalty = break_penalty,
                                  N = N,
                                  split = split,
                                  seed = seed,
                                  target_fpr = target_fpr,
                                  acceptance_margin = acceptance_margin,
                                  increment_factor = increment_factor,
                                  decrement_factor = decrement_factor,
                                  boundary = boundary)

  # The return value is a numeric vector with element names corresponding
  # to patch types for which the penalty parameter was calibrated.
  expect_true(is.numeric(result))
  expect_equal(names(result), c("rescale", "recode", "permute"))

  ####
  #### Test with the UCI 'abalone' dataset.
  ####
  df <- read_data("abalone", source = "uci")
  datadiff <- ddiff
  patch_generators <- list(gen_patch_rescale, gen_patch_recode)
  patch_penalties <- c(0.05, 0.2)
  permute_penalty <- 0.05
  break_penalty <- 0.95
  N <- 100
  split <- 0.5
  seed <- .Machine$integer.max
  target_fpr <- 0.1
  # Test with a wide acceptance margin.
  acceptance_margin <- 0.5
  increment_factor <- 1.2
  decrement_factor <- 0.8

  result <- iterative_calibration(df = df,
                     datadiff = datadiff,
                     patch_generators = patch_generators,
                     patch_penalties = patch_penalties,
                     permute_penalty = permute_penalty,
                     break_penalty = break_penalty,
                     N = N,
                     split = split,
                     seed = seed,
                     target_fpr = target_fpr,
                     acceptance_margin = acceptance_margin,
                     increment_factor = increment_factor,
                     decrement_factor = decrement_factor)

  # The return value is a numeric vector with element names corresponding
  # to patch types for which the penalty parameter was calibrated.
  expect_true(is.numeric(result))
  expect_equal(names(result), c("rescale", "recode", "permute"))

  ####
  #### Test with the UCI 'iris' dataset.
  ####
  df <- read_data("iris", source = "uci")
  datadiff <- ddiff
  patch_generators <- list(gen_patch_rescale, gen_patch_recode)
  patch_penalties <- c(0.05, 0.2)
  permute_penalty <- 0.05
  break_penalty <- 0.95
  N <- 100
  split <- 0.5
  seed <- .Machine$integer.max
  target_fpr <- 0.1
  # Test with a wide acceptance margin.
  acceptance_margin <- 0.5
  increment_factor <- 1.2
  decrement_factor <- 0.8

  result <- iterative_calibration(df = df,
                                  datadiff = datadiff,
                                  patch_generators = patch_generators,
                                  patch_penalties = patch_penalties,
                                  permute_penalty = permute_penalty,
                                  break_penalty = break_penalty,
                                  N = N,
                                  split = split,
                                  seed = seed,
                                  target_fpr = target_fpr,
                                  acceptance_margin = acceptance_margin,
                                  increment_factor = increment_factor,
                                  decrement_factor = decrement_factor)

  # The return value is a numeric vector with element names corresponding
  # to patch types for which the penalty parameter was calibrated.
  expect_true(is.numeric(result))
  expect_equal(names(result), c("rescale", "recode", "permute"))
})
