library(testthat)
library(datadiff)

test_check("datadiff")
