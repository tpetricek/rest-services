require(testthat)
context("dataset_url function")

test_that("the dataset_url function works", {

  ##
  ## Source: UCI Machine Learning Repository
  ##
  source <- "UCI"
  dataset <- "abalone"
  result <- dataset_url(source, dataset = dataset)

  expected <- "http://archive.ics.uci.edu/ml/machine-learning-databases/abalone/"
  expect_equal(result, expected = expected)

  ##
  ## Source: data.gov.uk
  ##
  source <- "data.gov.uk"
  dataset <- "broadband"

  result <- dataset_url(source, dataset = dataset, year = 2013)
  expected <- "https://www.ofcom.org.uk/__data/assets/excel_doc/0028/54775/november_2013.csv.xls"
  expect_equal(result, expected = expected)

  result <- dataset_url(source, dataset = dataset, year = 2014)
  expected <- "https://www.ofcom.org.uk/__data/assets/excel_doc/0014/74120/panellist_data_november_2014.csv.xls"
  expect_equal(result, expected = expected)

  result <- dataset_url(source, dataset = dataset, year = 2015)
  expected <- "https://www.ofcom.org.uk/__data/assets/excel_doc/0015/50073/panellist-data.csv.xls"
  expect_equal(result, expected = expected)

  result <- dataset_url(source, dataset = dataset, year = 2016)
  expected <- "https://www.ofcom.org.uk/__data/assets/file/0019/100756/UK-home-broadband-performance,-November-2016-Panellist-data.csv"
  expect_equal(result, expected = expected)

})
