require(testthat)
context("sample_patch function")

test_that("the sample_patch function works", {

  result <- sample_patch(mtcars, sample_patch_identity)
  expect_true(is_identity_patch(result))

  result <- sample_patch(mtcars, sample_patch_identity, sample_patch_identity)
  expect_true(is_identity_patch(result))

  result <- sample_patch(mtcars, sample_patch_permute)
  expect_true(is_patch(result))
  expect_equal(patch_type(result), expected = "permute")

  result <- sample_patch(mtcars, sample_patch_delete, sample_patch_permute)
  expect_true(is_patch(result))
  expect_equal(patch_type(result), expected = c("delete", "permute"))

  # Use do.call if the sampler functions are in a list.
  sampler_list <- list(sample_patch_delete, sample_patch_permute, sample_patch_rescale)
  result <- do.call(sample_patch, args = c(list(df = mtcars), sampler_list))

  expect_true(is_patch(result))
  expect_equal(patch_type(result), expected = c("delete", "permute", "rescale"))
})
